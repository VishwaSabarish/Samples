﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;

/// <summary>
/// Summary description for SecurityCredentials
/// </summary>
public class SecurityCredentials
{
	public SecurityCredentials()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    const string PassPhraseKey = "Medro";
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    /// <summary>
    /// code for encrypt the password;
    /// </summary>
    /// <param name="Message"></param>
    /// <returns></returns>
    public static string EncryptPassword(string Password)
    {
        byte[] encryptResults;
        UTF8Encoding UTF8 = new UTF8Encoding();
        MD5CryptoServiceProvider HashProvider = new MD5CryptoServiceProvider();
        byte[] TDESKey = HashProvider.ComputeHash(UTF8.GetBytes(PassPhraseKey));
        TripleDESCryptoServiceProvider TDESAlgorithm = new TripleDESCryptoServiceProvider();
        TDESAlgorithm.Key = TDESKey;
        TDESAlgorithm.Mode = CipherMode.ECB;
        TDESAlgorithm.Padding = PaddingMode.PKCS7;
        byte[] DataToEncrypt = UTF8.GetBytes(Password); /// it will encrypt your message
        try
        {
            ICryptoTransform Encryptor = TDESAlgorithm.CreateEncryptor();
            encryptResults = Encryptor.TransformFinalBlock(DataToEncrypt, 0, DataToEncrypt.Length);
        }
        finally
        {
            TDESAlgorithm.Clear();
            HashProvider.Clear();
        }
        return Convert.ToBase64String(encryptResults);
    }

    /// <summary>
    /// Code for Decrypt the password
    /// </summary>
    /// <param name="Message"></param>
    /// <returns></returns>
    public static string DecryptPassword(string Password)
    {
        byte[] Results;
        UTF8Encoding UTF8 = new UTF8Encoding();
        MD5CryptoServiceProvider HashProvider = new MD5CryptoServiceProvider();
        byte[] TDESKey = HashProvider.ComputeHash(UTF8.GetBytes(PassPhraseKey));
        TripleDESCryptoServiceProvider TDESAlgorithm = new TripleDESCryptoServiceProvider();
        TDESAlgorithm.Key = TDESKey;
        TDESAlgorithm.Mode = CipherMode.ECB;
        TDESAlgorithm.Padding = PaddingMode.PKCS7;
        byte[] DataToDecrypt = Convert.FromBase64String(Password); /// it will dycrpt your message
        try
        {
            ICryptoTransform Decryptor = TDESAlgorithm.CreateDecryptor();
            Results = Decryptor.TransformFinalBlock(DataToDecrypt, 0, DataToDecrypt.Length);
        }
        finally
        {
            TDESAlgorithm.Clear();
            HashProvider.Clear();
        }
        return UTF8.GetString(Results);
    }
}