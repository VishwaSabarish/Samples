﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

/// <summary>
/// Summary description for AutoCompletePatient
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
[System.Web.Script.Services.ScriptService]
public class AutoCompletePatient : System.Web.Services.WebService
{

    public AutoCompletePatient()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]

    public string[] PatientName(string prefixText)
    {

        List<Patient> patientlist = new Patient().list();
        var selectedlist = patientlist.Where(x => x.FirstName.ToLower().Contains(prefixText.ToLower()) || (x.LastName != null && x.LastName.ToLower().Contains(prefixText.ToLower())) || x.PatientNo.ToLower().Contains(prefixText.ToLower()) || x.PhoneNo.Contains(prefixText)).ToList();
        //var selectedlist = patientlist.Where(x => (x.LastName!= null && x.LastName.Contains(prefixText))).ToList();
        string[] patientsnames = new string[selectedlist.Count];
        for (int i = 0; i < selectedlist.Count; i++)
        {
            Patient patient = selectedlist[i];
            patientsnames[i] = patient.PatientID.ToString() + "~" + patient.PatientNo.ToString() + " ~ " + patient.FirstName.ToString() + " ~ " + ((patient.LastName == null) ? "" : patient.LastName.ToString()) + " ~ " + patient.PhoneNo.ToString();
        }

        return patientsnames;
    }

    [WebMethod]
    public string[] selectpatient(string prefixText)
    {
        string[] patientsnames = new string[5];
        if (prefixText != null)
        {
            Patient selectedpatient = new Patient(Convert.ToInt32(prefixText));
            //txtPatientNo.Text = selectedpatient.PatientNo;
            //ddlPatientType.SelectedValue = selectedpatient.PatientType;
            //txtfirstname.Text = selectedpatient.FirstName;
            //txtLastname.Text = selectedpatient.LastName;
            //ddlgender.SelectedValue = selectedpatient.Sex;
            //txtCOF.Text = selectedpatient.COF;
            //txtPhoneNo.Text = selectedpatient.PhoneNo;
            //txtAddress.Text = selectedpatient.Address;
            //txtAlrTo.Text = selectedpatient.AlrTo;
            patientsnames[0] = selectedpatient.PatientNo;
        }
        return patientsnames;
    }

    [WebMethod]
    public string[] chemicals(string prefixText)
    {
        List<Drug> druglist = new Drug().list();
        var selectedlist = druglist.Where(x => ((x.BrandName.ToLower().Contains(prefixText.ToLower())) || (x.ChemicalName != null && x.ChemicalName.ToLower().Contains(prefixText.ToLower()))) && x.IsDeleted == false).ToList();
        string[] chemicalsnames = new string[selectedlist.Count];

        int i = 0;
        foreach (Drug item in selectedlist)
        {
            chemicalsnames[i] = item.DrugID.ToString() + "~" + item.ChemicalName.ToString() + "~" + item.BrandName.ToString() + "~" + item.Dosage.ToString();
            i++;
        }

        //for (int i = 0; i < selectedlist.Count; i++)
        //{
        //    Drug drug = selectedlist[i];
        //    List<Stock> stocklist = new Stock().listindrugs(drug.DrugID);
        //    if (stocklist != null)
        //    {
        //        foreach (Stock item in stocklist)
        //        {
        //            chemicalsnames[i] = item.DrugID.ToString() + "~" + item.Drug.ChemicalName.ToString() + "~" + item.Drug.BrandName.ToString() + "~" + item.Drug.Dosage.ToString() + "~" + item.BatchID.ToString() + "~" + item.Quantity.ToString() + "~" + item.ExpiryDate.Value.ToString("dd/MM/yyyy");
        //        }
        //    }
        //}

        return chemicalsnames;
    }

    [WebMethod]
    public string[] doctorchemicals(string prefixText)
    {
        List<Drug> druglist = new Drug().list();
        List<Stock> stocklist = new Stock().list();
        var selectedlist = stocklist.Where(x => (x.Drug.BrandName.ToLower().Contains(prefixText.ToLower())) || (x.Drug.ChemicalName != null && x.Drug.ChemicalName.ToLower().Contains(prefixText.ToLower())) && x.Drug.IsDeleted == false).ToList();
        string[] chemicalsnames = new string[selectedlist.Count];
        for (int i = 0; i < selectedlist.Count; i++)
        {
            Stock item = selectedlist[i];
            if (item != null)
            {
                if (item.Drug.ReOrderQuantity != null)
                {
                    if (item.Quantity > item.Drug.ReOrderQuantity)
                    {
                        chemicalsnames[i] = item.DrugID.ToString() + "~" + item.Drug.ChemicalName.ToString() + "~" + item.Drug.BrandName.ToString() + "~" + item.Drug.Dosage.ToString();//+ "~" + item.BatchID.ToString() + "~" + item.Quantity.ToString() + "~" + item.ExpiryDate.Value.ToString("dd/MM/yyyy")    
                    }
                }
                else
                {
                    chemicalsnames[i] = item.DrugID.ToString() + "~" + item.Drug.ChemicalName.ToString() + "~" + item.Drug.BrandName.ToString() + "~" + item.Drug.Dosage.ToString();
                }
            }
        }
        //var selectedlist = druglist.Where(x => ((x.BrandName.ToLower().Contains(prefixText.ToLower())) || (x.ChemicalName != null && x.ChemicalName.ToLower().Contains(prefixText.ToLower()))) && x.IsDeleted == false).ToList();
        //string[] chemicalsnames = new string[selectedlist.Count];

        //for (int i = 0; i < selectedlist.Count; i++)
        //{
        //    Drug drug = selectedlist[i];
        //    List<Stock> stocklist = new Stock().listindrugs(drug.DrugID);
        //    if (stocklist != null)
        //    {
        //        foreach (Stock item in stocklist)
        //        {
        //            chemicalsnames[i] = item.DrugID.ToString() + "~" + item.Drug.ChemicalName.ToString() + "~" + item.Drug.BrandName.ToString() + "~" + item.Drug.Dosage.ToString();//+ "~" + item.BatchID.ToString() + "~" + item.Quantity.ToString() + "~" + item.ExpiryDate.Value.ToString("dd/MM/yyyy")
        //        }
        //    }
        //}

        chemicalsnames = chemicalsnames.Where(x => !string.IsNullOrEmpty(x)).ToArray();

        return chemicalsnames;
    }


    [WebMethod]
    public string[] Tests(string prefixText, string gender)
    {
        List<Investigation> invlist = new Investigation().list();
        var selectedlist = invlist.Where(x => x.TestName.ToLower().Contains(prefixText.ToLower()) || (x.SampleType.SampleTypeName != null && x.SampleType.SampleTypeName.ToLower().Contains(prefixText.ToLower()) || x.Fee.ToString().ToLower().Contains(prefixText.ToLower()))).ToList();
        //var selectedlist = patientlist.Where(x => (x.LastName!= null && x.LastName.Contains(prefixText))).ToList();
        selectedlist = selectedlist.Where(x => x.Sex == gender).ToList();
        string[] testsnames = new string[selectedlist.Count];
        for (int i = 0; i < selectedlist.Count; i++)
        {
            Investigation inv = selectedlist[i];
            testsnames[i] = inv.InvestigationID.ToString() + "~" + inv.TestName.ToString() + "~" + inv.SampleType.SampleTypeName.ToString() + "~" + inv.Fee.ToString();
        }

        return testsnames;
    }


}
