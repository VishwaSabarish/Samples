﻿using System.ComponentModel;

namespace Framework
{
    public static class Constant
    {
        public enum UserType
        {
            [Description("M")]
            Manager,
            [Description("S")]
            Staff,
            [Description("A")]
            Admin

        }

        public enum HeadingLiteral
        {
            [Description("Employent Type")]
            EmployeeType,
            [Description("Employer")]
            Employer,
            [Description("Department")]
            MaintenanceDepartment,
            [Description("Position")]
            Position,
            [Description("Site Users")]
            SiteUser,
            [Description("TimeSheet")]
            Timesheet,
            [Description("Affiliate")]
            Affiliate,
            [Description("Reporting Position")]
            ReportingTo,
            [Description("Holiday")]
            Holiday,
            [Description("Absents")]
            Absents,
            [Description("Work Group")]
            WorkGroup

        }
        public enum SessionVariables
        {
            [Description("LoggedUser")]
            User,
            [Description("LoggedUserRole")]
            UserRole
        }
        public enum ProjectPages
        {
            [Description("~/Booking/Login")]
            Login,
        }

        public enum RolesVariables
        {
            [Description("Custodian")]
            Custodian,
            [Description("Caretaker")]
            Caretaker,
            [Description("Receptionist")]
            Receptionist,
            [Description("Doctor")]
            Doctor,
            [Description("Pharmacist")]
            Pharmacist,
            [Description("Lab Technician")]
            LabTech,
            [Description("Actuarian")]
            Actuarian,
            [Description("Intermediary")]
            Intermediary,
            [Description("Stockist")]
            Stockist,
        }

        #region Conversion Methods
        public static int ToInt(this object Value)
        {
            int Integer;
            int.TryParse(Value.ToString(), out Integer);
            return Integer;
        }

        public static bool ToBool(this object Value)
        {
            bool Bool;
            bool.TryParse(Value.ToString(), out Bool);
            return Bool;
        }

        public static decimal ToDecimal(this object Value)
        {
            decimal Decimal;
            decimal.TryParse(Value.ToString(), out Decimal);
            return Decimal;
        }

        #endregion
    }

}
