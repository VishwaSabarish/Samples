﻿using System;
using System.ComponentModel;
using System.Reflection;

namespace Framework
{
    public static class Utilities
    {
        #region Extension methods


        public static string GetEnumDescription(Enum EnumConstant)
        {
            FieldInfo fiEnum = EnumConstant.GetType().GetField(EnumConstant.ToString());
            DescriptionAttribute[] descAttribute = (DescriptionAttribute[])fiEnum.GetCustomAttributes(typeof(DescriptionAttribute), false);
            if (descAttribute.Length > 0)
            {
                return descAttribute[0].Description;
            }

            return EnumConstant.ToString();
        }

        public static string Description(this Enum Value)
        {
            FieldInfo field = Value.GetType().GetField(Value.ToString());
            DescriptionAttribute attribute = Attribute.GetCustomAttribute(field, typeof(DescriptionAttribute)) as DescriptionAttribute;
            return attribute == null ? Value.ToString() : attribute.Description;
        }

        public static string GetContentType(string FileExtension)
        {
            string sContentType = "";
            switch (FileExtension)
            {
                case ".asf":
                    sContentType = "video/x-ms-asf";
                    break;
                case ".avi":
                    sContentType = "video/avi";
                    break;
                case ".doc":
                    sContentType = "application/msword";
                    break;
                case ".zip":
                    sContentType = "application/zip";
                    break;
                case ".xls":
                    sContentType = "application/vnd.ms-excel";
                    break;
                case ".gif":
                    sContentType = "image/gif";
                    break;
                case ".jpg":
                case "jpeg":
                    sContentType = "image/jpeg";
                    break;
                case ".wav":
                    sContentType = "audio/wav";
                    break;
                case ".mp3":
                    sContentType = "audio/mpeg3";
                    break;
                case ".mpg":
                case "mpeg":
                    sContentType = "video/mpeg";
                    break;
                case ".rtf":
                    sContentType = "application/rtf";
                    break;
                case ".htm":
                case "html":
                    sContentType = "text/html";
                    break;
                case ".asp":
                    sContentType = "text/asp";
                    break;
                case ".pdf":
                    sContentType = "application/pdf";
                    break;
                default:
                    //Handle All Other Files
                    sContentType = "application/octet-stream";
                    break;
            }
            return sContentType;
        }





        #endregion
    }
}