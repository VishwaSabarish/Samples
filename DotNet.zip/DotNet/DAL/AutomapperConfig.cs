﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class AutoMapperConfiguration
    {
        public static void ConfigureMapper()
        {          
            Mapper.CreateMap<Department, Department>();
            Mapper.CreateMap<Actuary, Actuary>();
            Mapper.CreateMap<Chart, Chart>();
            Mapper.CreateMap<DoctorNote, DoctorNote>();
            Mapper.CreateMap<Combo, Combo>();
            Mapper.CreateMap<Dispense, Dispense>();
            Mapper.CreateMap<Drug, Drug>();
            Mapper.CreateMap<Fee, Fee>();
            Mapper.CreateMap<HospitalDetail, HospitalDetail>();
            Mapper.CreateMap<Investigation, Investigation>();
            Mapper.CreateMap<MedicineDetail, MedicineDetail>();
            Mapper.CreateMap<MedicineType, MedicineType>();
            Mapper.CreateMap<Patient, Patient>();
            Mapper.CreateMap<PharmacyCombo, PharmacyCombo>();
            Mapper.CreateMap<Prescription, Prescription>();
            Mapper.CreateMap<Rebate, Rebate>();
            Mapper.CreateMap<Result, Result>();
            Mapper.CreateMap<Return, Return>();
            Mapper.CreateMap<SampleType, SampleType>();
            Mapper.CreateMap<Stock, Stock>();
            Mapper.CreateMap<Tax, Tax>();
            Mapper.CreateMap<User, User>();
            Mapper.CreateMap<UserRole, UserRole>();
            Mapper.CreateMap<Reception, Reception>();
            Mapper.CreateMap<BillingDetail, BillingDetail>();
            
            
        }
    }
}
