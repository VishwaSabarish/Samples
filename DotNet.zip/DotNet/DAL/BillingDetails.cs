﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    partial class BillingDetail : BaseObject
    {
           #region Properties and constructors

        public BillingDetail()
        {
        }
        public BillingDetail(long BillingDetailID)
        {
            using (MedroEntities dbcontext = new MedroEntities())
            {
                BillingDetail billingdetail = dbcontext.BillingDetails.FirstOrDefault(x => x.BillingDetailID == BillingDetailID);
                Mapper.Map(billingdetail, this);
            }
        }

        
        #endregion

        #region Helper methods

        protected override void Validate()
        {
            //if (string.IsNullOrEmpty(TaxName))
            //{
            //    AddMessage("please enter Tax Name");
            //}
            //if (IsExists())
            //{
            //    AddMessage("Tax Name already exists ");
            //}
        }

        //private bool IsExists()
        //{
        //    using (MedroEntities dbcontext = new MedroEntities())
        //    {
        //        BillingDetail billingdetail;
        //        if (string.IsNullOrEmpty(TaxName))
        //            billingdetail = dbcontext.BillingDetails.FirstOrDefault(x => x.TaxName == TaxName);
        //        else
        //            billingdetail = dbcontext.BillingDetails.FirstOrDefault(x => x.TaxName == TaxName && x.BillingDetailID != BillingDetailID);

        //        if (billingdetail == null)
        //        {
        //            return false;
        //        }
        //        return true;
        //    }
        //}

        protected override void StoreComposite()
        {
            if (BillingDetailID == 0)
            {
                AddImplementation();
            }
            else
            {
                UpdateImplementation();
            }
        }

        protected override void AddImplementation()
        {
            using (MedroEntities dbcontext = new MedroEntities())
            {
                dbcontext.BillingDetails.Add(this);
                dbcontext.SaveChanges();
            }
        }

        protected override void UpdateImplementation()
        {
            using (MedroEntities dbcontext = new MedroEntities())
            {
                BillingDetail updateobj = dbcontext.BillingDetails.FirstOrDefault(x => x.BillingDetailID == this.BillingDetailID);
                MapObject(updateobj);
                dbcontext.SaveChanges();
            }
        }

        protected override void DeleteImplementation()
        {
            using (MedroEntities dbcontext = new MedroEntities())
            {
                BillingDetail deleteobj = dbcontext.BillingDetails.FirstOrDefault(x => x.BillingDetailID == this.BillingDetailID);
                dbcontext.BillingDetails.Remove(deleteobj);
                dbcontext.SaveChanges();
            }
        }

        protected override void CustomDataTransform(object Instance)
        {
            throw new NotImplementedException();
        }

        #endregion

        public List<BillingDetail> list()
        {
            using (MedroEntities dbcontext = new MedroEntities())
            {
                List<BillingDetail> billingdetail = new List<BillingDetail>();
                billingdetail = dbcontext.BillingDetails.Include("Reception").Include("Drug").Include("MedicineDetail").Include("Investigation").ToList();
                return billingdetail;
            }
        }

        public List<BillingDetail> PaidList()
        {
            using (MedroEntities dbcontext = new MedroEntities())
            {
                List<BillingDetail> billingdetail = new List<BillingDetail>();
                DateTime startdate = DateTime.Now.AddHours(-24);
                DateTime enddate = DateTime.Now;
                billingdetail = dbcontext.BillingDetails.Where(x => (x.Reception.ReceptionDate > startdate && x.Reception.ReceptionDate <= enddate) && x.BillingStatus == "P").ToList();
                return billingdetail;
            }
        }

        public List<BillingDetail> UnpaidList()
        {
            using (MedroEntities dbcontext = new MedroEntities())
            {
                List<BillingDetail> billingdetail = new List<BillingDetail>();
                DateTime startdate = DateTime.Now.AddHours(-24);
                DateTime enddate = DateTime.Now;
                billingdetail = dbcontext.BillingDetails.Where(x => (x.Reception.ReceptionDate > startdate && x.Reception.ReceptionDate <= enddate) && x.BillingStatus == "U").ToList();
                return billingdetail;
            }
        }

        public List<BillingDetail> List(long ReceptionID)
        {
            using (MedroEntities dbcontext = new MedroEntities())
            {
                List<BillingDetail> billingdetail = new List<BillingDetail>();
                billingdetail = dbcontext.BillingDetails.Include("Reception").Where(x => x.ReceptionID == ReceptionID).OrderBy(x => x.BillingDetailID).ToList();
                return billingdetail;
            }
        }

        public BillingDetail getBillingDetailbyID(int BillingDetailID)
        {
            using (MedroEntities dbcontext = new MedroEntities())
            {
                BillingDetail billingdetail = new BillingDetail();
                billingdetail = dbcontext.BillingDetails.Where(x => x.BillingDetailID == BillingDetailID).FirstOrDefault();
                return billingdetail;
            }
        }
        public List<BillingDetail> TestListLast24Hours()
        {
            using (MedroEntities dbcontext = new MedroEntities())
            {
                List<BillingDetail> billingdetail = new List<BillingDetail>();
                DateTime startdate = DateTime.Now.AddHours(-24);
                DateTime enddate = DateTime.Now;
                billingdetail = dbcontext.BillingDetails.Where(x => (x.Reception.ReceptionDate > startdate && x.Reception.ReceptionDate <= enddate) && x.BillingType == "L" && x.BillingStatus == "P").ToList();
                return billingdetail;
            }
        }
        public List<BillingDetail> YesterdayTestList()
        {
            using (MedroEntities dbcontext = new MedroEntities())
            {
                List<BillingDetail> billingdetail = new List<BillingDetail>();
                DateTime startdate = DateTime.Now.AddDays(-2);
                DateTime enddate = DateTime.Now.AddDays(-1);
                billingdetail = dbcontext.BillingDetails.Where(x => (x.Reception.ReceptionDate > startdate && x.Reception.ReceptionDate <= enddate) && x.BillingType == "L" && x.BillingStatus == "P").ToList();
                return billingdetail;
            }
        }


    }
}
