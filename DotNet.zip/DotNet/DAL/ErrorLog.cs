﻿using System;
using System.Collections.Generic;
using System.Linq;
using Framework;
using System.IO;
using System.Text;
using System.Web;
namespace DAL
{
    public partial class ErrorLog : BaseObject
    {
      

        #region Helper Methods        
        
        public static void AddErrorLog(string MachineName,  Exception exception)
        {
            try
            {

                string sFileName = HttpContext.Current.Server.MapPath("~/App_Data/logfile.txt");                

                StreamWriter sw = new StreamWriter(sFileName, true);
                sw.WriteLine(MachineName + " on " + DateTime.Now.ToString() + " - " + exception.ToString()) ;
                sw.Flush();
                sw.Close();               

               
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

      
        #endregion

        #region Helper methods

        protected override void Validate()
        {
           

        }

        protected override void StoreComposite()
        {
           
        }

        protected override void AddImplementation()
        {
           
        }

        protected override void UpdateImplementation()
        {
            
        }

        protected override void DeleteImplementation()
        {
            
        }

        protected override void CustomDataTransform(object Instance)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}