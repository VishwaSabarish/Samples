﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
   public abstract class BaseObject
    {

        public bool HasError;
        public bool IstoBeDeleted = false;
        public List<string> ErrorMessage;

        #region Delegates and events
        //public delegate UserInfo ApplicationUser();
        //public static event ApplicationUser LoggedInUser;
        #endregion

        #region Abstract methods

        protected abstract void Validate();

        protected abstract void StoreComposite();

        protected abstract void AddImplementation();

        protected abstract void UpdateImplementation();

        protected abstract void DeleteImplementation();

        protected abstract void CustomDataTransform(object Instance);

        #endregion

        #region Store

        public void Store()
        {
            //UserInfo user = null;
            //if (LoggedInUser != null)
            //{
            //    user = LoggedInUser.Invoke();
            //}

            //if (user == null)
            //{
            //    throw new UnauthorizedAccessException();
            //}

            if (IstoBeDeleted)
            {
                DeleteImplementation();
                return;
            }

            ResetMessage();
            Validate();

            if (HasError)
            {
                return;

            }
            else { StoreComposite(); }
            

          
        }

        #endregion

        #region Helper Methods

        protected void AddMessage(string Message)
        {
            if (ErrorMessage == null)
            {
                ResetMessage();
            }

            ErrorMessage.Add(Message);
            HasError = true;
        }
        public string GetMessage(string separator = "<br />")
        {
            if (ErrorMessage == null)
            {
                return string.Empty;
            }

            return string.Join(separator, ErrorMessage);
        }
        private void ResetMessage()
        {
            ErrorMessage = new List<string>();
            HasError = false;
        }

        //protected UserInfo GetUserContext()
        //{
        //    return LoggedInUser.Invoke();
        //}
        protected void MapObject(object Destination)
        {
            PropertyInfo[] properties = GetType().GetProperties().Where(x => (x.Name != "CreatedBy" && x.Name != "CreatedOn") && x.CanWrite && (!x.PropertyType.IsClass || x.PropertyType.UnderlyingSystemType == typeof(string))).ToArray();
            foreach (PropertyInfo property in properties)
            {
                property.SetValue(Destination, property.GetValue(this, null), null);
            }
        }
        #endregion
    }
}
